create
    definer = root@localhost procedure insertIntoSubjectType(IN Name varchar(45))
BEGIN
INSERT INTO `dbstudentbg`.`subjecttype`
(`Name`)
VALUES
(Name);

END;

